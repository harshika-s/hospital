<html>
<head>
  <title>Create a Branch</title>
</head>
<body>
  <?php
   $dbhost = "localhost";
   $port = "5432";
   $dbname = "hospital";
   $dbuser = "postgres";
   $dbpass = "dam999";
 
   // Connect to PostgreSQL
   $conn = pg_connect("host=$dbhost dbname=$dbname user=$dbuser password=$dbpass");



  if (!$conn) {
    die("Connection failed: " . pg_last_error());
  }

  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $branchName = $_POST['name'];

    $query = "INSERT INTO branch (name) VALUES ('$branchName')";

    if (pg_query($conn, $query)) {
      echo "Branch created successfully!";
    } else {
      echo "Error creating branch: " . pg_last_error($conn);
    }
  }
  ?>
  <form action="createBranch.php" method="post">
   <p>Branch name: <input type="text" name="name" /></p>

   <p><input type="submit" /></p>
 </form>  

 <br />

 Click <a href="http://localhost/hospital/logout.php">here</a> to log out.
</body>
</html>
