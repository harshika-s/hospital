<html>
<head>
  <title>Create a Doctor</title>
</head>
<body>
  <?php
  $dbhost = "localhost";
  $port = "5432";
  $dbname = "hospital";
  $dbuser = "postgres";
  $dbpass = "dam999";

  // Connect to PostgreSQL
  $conn = pg_connect("host=$dbhost port=$port dbname=$dbname user=$dbuser password=$dbpass");

  // Check connection
  if (!$conn) {
    die("Connection failed: " . pg_last_error());
  }

  // Process form submission
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fname = pg_escape_string($_POST["fname"]);
    $lname = pg_escape_string($_POST["lname"]);
    $branch = pg_escape_string($_POST["Branch"]);

    // Insert data into the database
    $insert_query = "INSERT INTO Doctor (fname, lname, branch) VALUES ('$fname', '$lname', '$branch')";
    $result = pg_query($conn, $insert_query);

    if ($result) {
      echo "Doctor created successfully.";
    } else {
      echo "Error: " . pg_last_error();
    }
  }
  ?>
  <form action="createDoctor.php" method="post">
    <p>First name: <input type="text" name="fname" /></p>
    <p>Last name: <input type="text" name="lname" /></p>
    <select name="Branch">
      <?php
      $branch_query = "SELECT name FROM branches";
      $branch_result = pg_query($conn, $branch_query);

      while ($row2 = pg_fetch_assoc($branch_result)) {
        echo "<option value='" . $row2['name'] . "'>" . $row2['name'] . "</option>";
      }
      ?>
    </select>
    <p><input type="submit" /></p>
  </form>

  <br />

  Click <a href="http://localhost/hospital/logout.php">here</a> to log out.
</body>
</html>

