<html>
<head>
  <title>User Home Page</title>
</head>
<body>
  <?php
  ?>
  Click <a href="http://localhost/hospital/logout.php">here</a> to log out.
  <br>
  <a href='http://localhost/hospital/addDoctor.php'>Create a doctor</a>
  <br>
  <a href='http://localhost/hospital/removeDoctor.php'>Remove a doctor</a>
  <br>
  <a href='http://localhost/hospital/editDoctor.php'>Edit a doctor</a>
  <br>
  <a href='http://localhost/hospital/addBranch.php'>Create a branch</a>
  <br>
  <a href='http://localhost/hospital/removeBranch.php'>Remove a branch</a>
  <br>
  <a href='http://localhost/hospital/editBranch.php'>Edit a branch</a>

  <?php
  ?>

</body>
</html>
