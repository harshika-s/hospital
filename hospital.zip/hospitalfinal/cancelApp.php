<?php
$dbhost = "localhost";
$port = "5432";
$dbname = "hospital";
$dbuser = "postgres";
$dbpass = "dam999";

// Connect to PostgreSQL
$conn = pg_connect("host=$dbhost dbname=$dbname user=$dbuser password=$dbpass");

// Check connection
if ($conn) {
    session_start();

    $del_query = "DELETE FROM Appointment WHERE id = " . $_POST['app'];
    $result = pg_query($conn, $del_query);

    echo "Appointment canceled successfully.<br/>";
} else {
    die("Connection failed: " . pg_last_error());
}

// Close the connection
pg_close($conn);
?>
