<html>
<head>
  <title>Make an Appointment Page</title>
</head>
<body>
  <?php
    $dbhost = "localhost";
    $port = "5432";
    $dbname = "hospital";
    $dbuser = "postgres";
    $dbpass = "dam999";
  
    // Connect to PostgreSQL
    $conn = pg_connect("host=$dbhost dbname=$dbname user=$dbuser password=$dbpass");

    // Check connection
    if (!$conn) {
      die("Failed to connect to PostgreSQL.");
    } else {
      session_start();

      // Ensure $_SESSION['id'] is set before using it in the query
      if (!isset($_SESSION['id'])) {
        die("User ID not set in the session.");
      }

      $query = "SELECT * FROM Appointment WHERE patient_id = " . $_SESSION['id'];

      $result = pg_query($conn, $query);

      if ($result) {
        ?>
        <table border="1">
          <?php
          while ($row2 = pg_fetch_assoc($result)) {
            $hour = sprintf("%02d", 8 + intval($row2['hour'] / 12));
            $min = sprintf("%02d", $row2['hour'] % 12 * 5);
            $sql = "SELECT fname, lname FROM Doctor WHERE id = '" . $row2['doctor_id'] . "'";
            $resultDoctor = pg_query($conn, $sql);
            $rowDoctor = pg_fetch_assoc($resultDoctor); 
            echo "<tr><th>" . $rowDoctor['fname'] . " " . $rowDoctor['lname'] .  "," . $hour . ":" . $min . "</th>";
            ?>
            <th>
              <form action="cancelApp.php" method="post">
                <input type="hidden" name="app" value="<?php echo $row2['id'];?>">
                <input type="submit" value="cancel">
              </form>
            </th>
          </tr>
          <?php
        }
      } else {
        die("Query failed: " . pg_last_error($conn));
      }
    }
  ?>
</table>  
</body>
</html>

