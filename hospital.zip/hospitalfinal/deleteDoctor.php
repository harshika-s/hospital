<?php
 $dbhost = "localhost";
 $port = "5432";
 $dbname = "hospital";
 $dbuser = "postgres";
 $dbpass = "dam999";

 // Connect to PostgreSQL
 $conn = pg_connect("host=$dbhost dbname=$dbname user=$dbuser password=$dbpass");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    $old_doctor = $_POST["Old_Doctor"];

    $sql = "DELETE FROM Doctor WHERE id = '$old_doctor' ";

    if ($conn->query($sql) === TRUE) {
        // Redirect to the specified location
        header("Location: http://localhost/hospital/admin.php");
        die();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
</body>
</html>
