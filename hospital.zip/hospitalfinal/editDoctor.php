<html>
<head>
  <title>Edit a Doctor</title>
</head>
<body>
  <?php
    $dbhost = "localhost";
    $port = "5432";
    $dbname = "hospital";
    $dbuser = "postgres";
    $dbpass = "dam999";
  
    // Connect to PostgreSQL
    $conn = pg_connect("host=$dbhost dbname=$dbname user=$dbuser password=$dbpass");
  ?>
  <form action="modifyDoctor.php" method="post">
    <select name="Old_Doctor">
      <?php
      $id_doctor_query = "SELECT id, fname, lname FROM Doctor";
      $id_result = $conn->query($id_doctor_query);
      while ($row2 = $id_result->fetch_assoc()) {
        echo "<option value='".$row2['id']."'>" . $row2['fname'] . " " . $row2['lname'] . "</option>";
      }
      ?>
    </select>
    <p>fname: <input type="text" name="fname" /></p>
    <p>lname: <input type="text" name="lname" /></p>
    <select name="Branch">
      <?php
      $id_doctor_query = "SELECT name FROM Branches";
      $id_result = $conn->query($id_doctor_query);
      while ($row2 = $id_result->fetch_assoc()) {
        echo "<option value='".$row2['name']."'>" . $row2['name'] . "</option>";
      }
      ?>
    </select>
    <p><input type="submit" /></p>
  </form>  
  <br />
  Click <a href="http://localhost/hospital/logout.php">here</a> to log out.
</body>
</html>
