<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Home Page</title>
</head>
<body>

<?php
  session_start();

  $dbhost = "localhost";
  $port = "5432";
  $dbname = "hospital";
  $dbuser = "postgres";
  $dbpass = "dam999";

  // Connect to PostgreSQL
  $conn = pg_connect("host=$dbhost dbname=$dbname user=$dbuser password=$dbpass");

  if (!$conn) {
    echo "Failed to connect to PostgreSQL.";
    exit;
  }

  if (!isset($_SESSION['username'])) {
    $msg = "Please <a href='http://localhost/hospital/index.php'>register</a> to view this page";
    echo $msg;
  } else {
    $username = $_SESSION['username'];
    // Customize the SQL query based on your actual user table
    $result = pg_query($conn, "SELECT * FROM patient WHERE username = '$username'");
    
    if ($row = pg_fetch_assoc($result)) {
      echo "Welcome, " . $row['username'] . ".";
      ?>
      <br />
      Click <a href="http://localhost/hospital/logout.php">here</a> to log out.
      <br>
      <a href='http://localhost/hospital/makeAppointment.php'>Make an appointment</a>
      <br>
      <a href='http://localhost/hospital/cancelAppointment.php'>Cancel an appointment</a>
      <br>
      <a href='http://localhost/hospital/editAppointment.php'>Edit an appointment</a>
      <?php
    }
  }

  pg_close($conn);
?>
</body>
</html>



