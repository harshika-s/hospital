<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style>
        body {
            background-image: url('https://www.google.com/url?sa=i&url=https%3A%2F%2Fin.pinterest.com%2Fpin%2Ffree-photo--114138171793360663%2F&psig=AOvVaw37sYYGMecCs-wm0rbeF8fy&ust=1702830297253000&source=images&cd=vfe&opi=89978449&ved=0CBIQjRxqFwoTCKDdt7SvlIMDFQAAAAAdAAAAABAI'); /* Replace with the path to your background image */
            background-size: cover;
            font-family: 'Arial', sans-serif; /* Replace with your preferred font */
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
        }

        form {
            background-color: rgba(255, 255, 255, 0.8); /* Adjust the background color opacity */
            padding: 20px;
            border-radius: 10px;
            text-align: center;
        }

        input {
            margin-bottom: 10px;
            padding: 8px;
            width: 100%;
        }

        button {
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <form action="your_login_script.php" method="post">
        <h2>Login</h2>
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="pass" placeholder="Password" required>
        <button type="submit">Login</button>
    </form>
</body>
</html>

<?php
  session_start();

  // Adjust your PostgreSQL connection parameters
  $dbhost = "localhost";
  $port = "5432";
  $dbname = "hospital";
  $dbuser = "postgres";
  $dbpass = "dam999";

  // Connect to PostgreSQL
  $conn = pg_connect("host=$dbhost dbname=$dbname user=$dbuser password=$dbpass");

  if (!$conn) {
    echo "Failed to connect to PostgreSQL.";
    exit;
  }

  if (!isset($_SESSION['username'])) {
    $msg = "Please <a href='http://localhost/hospital/registration.php'>register</a> to view this page";
    echo $msg;
    ?>

    <form action="login.php" method="post">
     <p>Username: <input type="text" name="username" /></p>
     <p>Password: <input type="password" name="pass" /></p>
     <p><input type="submit" /></p>
   </form>  
   <?php
  } else {
    echo "Welcome, " . $_SESSION['username'] . ".";
    ?>
    <br />
    Click <a href="http://localhost/hospital/logout.php">here</a> to log out.
    <?php
  }

  // Close the PostgreSQL connection
  pg_close($conn);
?>
</body>
</html>
