<?php
  $dbhost = "localhost";
  $port = "5432";
  $dbname = "hospital";
  $dbuser = "postgres";
  $dbpass = "dam999";

  // Connect to PostgreSQL
  $conn = pg_connect("host=$dbhost dbname=$dbname user=$dbuser password=$dbpass");

  // Check connection
  if (!$conn) {
    die("Connection failed: " . pg_last_error());
  } else {
    session_start();

    $make_query = "INSERT INTO Appointment (doctor_id, patient_id, hour, date) VALUES ('" . $_POST['Doctor'] . "', '" . $_SESSION['id'] . "', '" . $_POST['Hour'] . "' , '" . $_POST['Date'] . "')";
    $result = pg_query($conn, $make_query);

    if ($result) {
      echo "Appointment created successfully.<br/>";
    } else {
      echo "Error: " . $make_query . "<br>" . pg_last_error($conn);
    }
  }

  // Close the PostgreSQL connection
  pg_close($conn);
?>
