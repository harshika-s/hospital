<html>
<head>
  <title>Make an Appointment Page</title>
</head>
<body>
  <?php
    $dbhost = "localhost";
    $port = "5432";
    $dbname = "hospital";
    $dbuser = "postgres";
    $dbpass = "dam999";
  
    // Connect to PostgreSQL
    $conn = pg_connect("host=$dbhost dbname=$dbname user=$dbuser password=$dbpass");

  if (!$conn) {
    die("Failed to connect to PostgreSQL.");
  } else {
    echo "<form action='makeAppointment.php' method='post'>";

    $sql = "SELECT fname, branch FROM Doctor";
    $result = pg_query($conn, $sql);

    echo "<p>Branch: <select name='Branch'>";

    // to fetch branches from the database
    if ($result) {
      while ($row = pg_fetch_assoc($result)) {
        echo "<option value='" . $row['branch'] . "'>" . $row['branch'] . "</option>";
      }
    }

    echo "</select></p>";

    $sql = "SELECT fname, id FROM Doctor";
    $result = pg_query($conn, $sql);

    echo "<p>Doctor: <select name='Doctor'>";

    // to fetch doctors from the database
    if ($result) {
      while ($row = pg_fetch_assoc($result)) {
        echo "<option value='" . $row['id'] . "'>" . $row['fname'] . "</option>";
      }
    }

    echo "</select></p>";

    echo "<p>Date: <select name='Date'>";
    $day_counts = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    for ($i = 0; $i < 12; $i++) {
      for ($j = 1; $j <= $day_counts[$i]; $j++) {
        $date_value = "2017-" . ($i+1) . "-" . $j;
        echo "<option value='" . $date_value . "'>" . ($i+1) . "/" . $j . "</option>";
      }
    }
    echo "</select></p>";

    echo "<p><input type='submit' /></p>";
    echo "</form>";

    if (isset($_POST['Branch'])) {
      $sql = "SELECT hour FROM Appointment WHERE doctor_id=" . $_POST['Doctor'] . " AND date='" . $_POST['Date'] . "'";

      $hour_arr = str_repeat('0', 96);

      $result = pg_query($conn, $sql);

      while ($row = pg_fetch_assoc($result)) {
        $hour_arr[intval($row['hour'])] = '1';
      }

      ?>
      <table>
        <tr>
          <?php
          for ($i = 0; $i < 96; $i++) {
            $hour = sprintf("%02d", 8+intval($i/12));
            $min = sprintf("%02d", $i%12 * 5);

            if ($hour > 11) {
              $hour++;
            }
            if ($hour_arr[$i] == '1') {
              echo "<th><span class='busy'>" . $hour . ":" . $min . "</th>";
              continue;
            }
            ?>
            <th>
              <form action="makeApp.php" method="post">
                <input type="hidden" name="Hour" value="<?php echo $i; ?>">
                <input type="hidden" name="Date" value="<?php echo $_POST['Date']; ?>">
                <input type="hidden" name="Doctor" value="<?php echo $_POST['Doctor']; ?>">
                <input type="submit" value="<?php echo $hour . ":" . $min; ?>">
              </form>
            </th>
            <?php
            if (($i+1) % 12 == 0) {
              echo "</tr><tr>";
            }
          }
          ?>
        </tr>
      </table>
      <?php
    }
    echo "</tr>";
    echo "</table>";
  }
  ?>

</body>
</html>
