<?
  $dbhost = "localhost";
  $port = "5432";
  $dbname = "hospital";
  $dbuser = "postgres";
  $dbpass = "dam999";

  // Connect to PostgreSQL
  $conn = pg_connect("host=$dbhost dbname=$dbname user=$dbuser password=$dbpass");

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
} else {
  $old_branch = $_POST["Old_Branch"];
  $name = $_POST["name"];

  $sql = "UPDATE Branches SET name = '$name' WHERE id = '$old_branch'";

  $result = $conn->query($sql);
}

$conn->close();
header("Location:http://localhost/hospital/admin.php");
die();
?>
</body>
</html>
