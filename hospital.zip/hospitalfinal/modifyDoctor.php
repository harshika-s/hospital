<?
  $dbhost = "localhost";
  $port = "5432";
  $dbname = "hospital";
  $dbuser = "postgres";
  $dbpass = "dam999";

  // Connect to PostgreSQL
  $conn = pg_connect("host=$dbhost dbname=$dbname user=$dbuser password=$dbpass");

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
} else {
  $old_doctor = $_POST["Old_Doctor"];
  $branch = $_POST["Branch"];
  $fname = $_POST["fname"];
  $lname = $_POST["lname"];

  $sql = "UPDATE Doctor SET fname = '$fname', lname = '$lname', branch = '$branch' WHERE id = '$old_doctor'";

  $result = $conn->query($sql);
}

$conn->close();
header("Location:http://localhost/hospital/admin.php");
die();
?>
</body>
</html>
