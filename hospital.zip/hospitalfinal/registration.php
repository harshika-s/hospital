<html>
<head>
  <title>Home Page</title>
</head>
<body>
  <?php
  session_start();

  $dbhost = "localhost";
  $port = "5432";
  $dbname = "hospital";
  $dbuser = "postgres";
  $dbpass = "dam999";

  // Connect to PostgreSQL
  $conn = pg_connect("host=$dbhost dbname=$dbname user=$dbuser password=$dbpass");

  if (!$conn) {
    echo "Failed to connect to PostgreSQL.";
    exit;
  }

  if (!isset($_SESSION['username'])) {
    ?>

    <form action="create_user.php" method="post">
     <p>Username: <input type="text" name="id" /></p>
     <p>Password: <input type="password" name="pass" /></p>
     <p>First Name: <input type="text" name="fname" /></p>
     <p>Last Name: <input type="text" name="lname" /></p>
     <p><input type="submit" /></p>
   </form>  
   <?php      } else {
     ?>
     <br />

     Click <a href="http://localhost/hospital/logout.php">here</a> to log out.

     <?php 
   }

   pg_close($conn);
   ?>

 </body>
 </html>
