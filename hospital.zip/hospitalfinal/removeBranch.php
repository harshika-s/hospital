<html>
<head>
  <title>Home Page</title>
</head>
<body>
  <?php
    $dbhost = "localhost";
    $port = "5432";
    $dbname = "hospital";
    $dbuser = "postgres";
    $dbpass = "dam999";
  
    // Connect to PostgreSQL
    $conn = pg_connect("host=$dbhost dbname=$dbname user=$dbuser password=$dbpass");

  if (!$conn) {
    echo "Failed to connect to PostgreSQL.";
    exit;
  }

  ?>
  <form action="deleteBranch.php" method="post">
   <select name="Old_Branch">
    <?php
    $id_branch_query = "SELECT name, id FROM Branches";
    $id_result = pg_query($conn, $id_branch_query);
    while ($row2 = pg_fetch_assoc($id_result)) {
      echo "<option value='".$row2['id']."'>" . $row2['name'] . "</option>";
    }
    ?>
    
  </select>

  <p><input type="submit" /></p>
</form>  

<br />

Click <a href="http://localhost/hospital/logout.php">here</a> to log out.

<?php
  pg_close($conn);
?>
</body>
</html>
