<html>
<head>
  <title>Home Page</title>
</head>
<body>
  <?php
    $dbhost = "localhost";
    $port = "5432";
    $dbname = "hospital";
    $dbuser = "postgres";
    $dbpass = "dam999";
  
    // Connect to PostgreSQL
    $conn = pg_connect("host=$dbhost dbname=$dbname user=$dbuser password=$dbpass");

    if (!$conn) {
      die("Connection failed: " . pg_last_error());
    }
  ?>
  <form action="deleteDoctor.php" method="post">
    <select name="Old_Doctor">
      <?php
      $id_doctor_query = "SELECT id, fname, lname FROM Doctor";
      $id_result = pg_query($conn, $id_doctor_query);
      while ($row2 = pg_fetch_assoc($id_result)) {
        echo "<option value='".$row2['id']."'>" . $row2['fname'] . " " . $row2['lname'] . "</option>";
      }
      ?>
    </select>

    <p><input type="submit" /></p>
  </form>  

  <br />

  Click <a href="http://localhost/hospital/logout.php">here</a> to log out.

  <?php
    // Close the PostgreSQL connection
    pg_close($conn);
  ?>
</body>
</html>
